#! /bin/bash
#script to test if-elif-else

if [ $1 -gt 0 ]
then 
	echo "$1 is positive"
elif [ $1 -lt 0 ]
then 
	echo "$1 is negative"
elif [ $1 -eq 0 ]
then
	echo "$1 is equal to zero"
else
	echo "it is not a number"
fi

