#! /bin/bash
#script to find is positive
if test $1 -gt 0
then
	echo "the number is positive"
fi
