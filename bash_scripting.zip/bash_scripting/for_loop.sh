#! /bin/bash
#for loop to print the first 10 natural numbers


