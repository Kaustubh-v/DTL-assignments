#! /bin/bash
#script to test rm command and exit status

if rm $1
then
	echo "$1 file deleted"
fi

