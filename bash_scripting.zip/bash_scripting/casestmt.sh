#! /bin/bash
#case statements

if [ $# -eq 0 ]
then 
	echo "ERROR"
	exit 1
fi

car=$1

case $car in
	"car") echo "For $car rental is Rs.21" ;;
	"van") echo "For $car rental is Rs.30" ;;
	"jeep") echo "For $car rental is Rs 40" ;;
	*) echo "Sorry no rental cars for you" ;;
esac

