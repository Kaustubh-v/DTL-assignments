#! /bin/bash
#implementing a while loop

if [ $# -eq 0 ]
then
	echo "Error"
	exit 1
fi
n=$1
i=1
echo "the code is running"
while [ $i -le 10 ]
do
	mul=$(($n * $i))
	echo "$n * $i = $mul"
	((i++))
done
