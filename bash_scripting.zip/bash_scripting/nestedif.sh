#! /bin/bash
#implementing nested if

osch=0

echo "1. Unix (Sun OS)"
echo "2. Linux (Red Hat)"
echo "Select your os choice [1 or 2]"
read osch

if [ $osch -eq 1 ]
then 
	echo "you have selected Unix"
else 
	if [ $osch -eq 2 ]
	then 
		echo "you have selected Linux"
	else
		echo "What you dont like Unix/Linux?"
	fi
fi
