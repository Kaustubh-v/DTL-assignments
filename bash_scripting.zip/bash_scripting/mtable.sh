#! /bin/bash
#for loop testing

if [ $# -eq 0 ]
then
	echo "Error"
	exit 1
fi

n=$1
for i in {1..10}
do
	mul=$((n*i))
	echo "$n x $i = $mul"
done

