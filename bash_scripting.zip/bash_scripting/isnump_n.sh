#! /bin/bash
#find if the number is positive or negative

if [ $# -eq 0 ]
then 
	echo "please enter an argument"
	exit 1
fi

if test $1 -gt 0
then 
	echo "$1 number is positive"
else 
	echo "$1 number is negative"
fi
